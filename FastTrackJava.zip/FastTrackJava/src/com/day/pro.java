package com.day;

import com.day1.pro1;

public class pro extends pro1 {
	public static void main(String[] args) {
		pro obj = new pro();
		obj.display();
	}
}

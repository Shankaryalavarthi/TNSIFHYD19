package com.day;

import com.day1.pub;

public class pub1 {
	public static void main(String[] args) {
		pub obj = new pub();
		obj.display();
		
	}

}

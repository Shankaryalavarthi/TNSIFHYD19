package com.day1;

public class pub {
	public void display() {
		System.out.println("shankar");
	}

}

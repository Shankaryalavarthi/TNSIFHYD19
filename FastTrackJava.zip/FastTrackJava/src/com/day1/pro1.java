package com.day1;

public class pro1 {
	protected void display() {
		System.out.println("shankar");
	}
}

package com.day1;

public class Private {

	private void display() {
		System.out.println("shankar");
	}
} 
class B{
	public static void main(String[] args) {
		private obj= new private();
		obj.display();
		
	}
}
